<?php 
include( get_template_directory(). '/inc/enqueue.php' );
include( get_template_directory(). '/inc/support.php' );
