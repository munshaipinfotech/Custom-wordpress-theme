<?php 
include( get_template_directory(). '/inc/enqueue.php' );
include( get_template_directory(). '/inc/theme_support.php' );
include( get_template_directory(). '/inc/support.php' );
