<?php
/**
 * Plugins Support
 *
 * @since 1.5.0
 */

// WooCommerce Support.
add_theme_support( 'woocommerce' );
