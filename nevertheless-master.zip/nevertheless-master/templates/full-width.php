<?php
/**
 * Template Name: Full Width
**/
if( function_exists( 'tamatebako_set_layout' ) ){
	tamatebako_set_layout( 'content' );
}
get_template_part( 'index' );
