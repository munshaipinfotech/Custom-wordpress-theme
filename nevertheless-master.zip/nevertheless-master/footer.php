<footer id="footer">

	<?php get_template_part( 'menu/footer' ); ?>

</footer><!-- #footer -->