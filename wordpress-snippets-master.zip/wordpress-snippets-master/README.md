# WordPress Snippets Snippets

A collection of WordPress utilities by [MarchettiDesign.net](http://www.marchettidesign.net/)


## List of the utilities

- Custom Post Type

- Basic Functions.php

- Gallery Loop

- Image Background Single Post / Page

- Loop Custom

- Loop with Pagination

- Loop with filter based on Template selected

- Loop Standard

- Taxonomy Menu

- Taxonomy

- Woocommerce Scripts Optimizations


## Usage
Copy and paste the snippets.

## Licensing
MIT © 2016 [Andrea Marchetti](http://www.marchettidesign.net/)
