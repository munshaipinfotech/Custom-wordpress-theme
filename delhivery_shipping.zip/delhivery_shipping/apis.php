<?php
//APIS

/** CHECK PINCODE API **/
function checkPincode($filter_codes){
// HEADERS
	$headers[] = "";

	// PARAMS
	$token =  getAPIToken();
	$mode  =  getApiMode();
	//$filter_codes = "384001";


	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

    $myurl = $mode =='0' ?
		  "https://test.delhivery.com/c/api/pin-codes/json/?token=$token&filter_codes=$filter_codes" :
		  "https://track.delhivery.com/c/api/pin-codes/json/?token=$token&filter_codes=$filter_codes" ;								
	//$myurl = "https://track.delhivery.com/c/api/pin-codes/json/?token=$token&filter_codes=$filter_codes";	
   
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	//$result = json_encode($result);
	//echo $result;
	return $result;
    
 }

/** CREATE PACKAGE ORDER API **/
function createPackageOrder($data){
	// HEADERS
	$headers[] = "";
	
	// PARAMS
	$token =  getAPIToken();
	$mode  =  getApiMode();

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

	$myurl = $mode =='0' ?
			"https://test.delhivery.com/cmu/push/json/?token=$token" :
			"https://track.delhivery.com/cmu/push/json/?token=$token" ;
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_POSTFIELDS,"format=".$data['format']."&data=".$data['data']); 
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	return $result;
}


/** PICKUP REQUEST API **/
function createPickupRequest($data){

	$token =  getAPIToken();
	$mode  =  getApiMode();

	// headers
	$headers[] = "Authorization: Token $token";
	$headers[] = "Content-Type: application/json";

	// PARAMS
	//$token =  "6cb9c561f0b293836847e78b66d5f8be70566719";

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

	$myurl = $mode =='0' ?
				"https://test.delhivery.com/fm/request/new/":
				"https://track.delhivery.com/fm/request/new/";
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
        
	$curl_error = curl_errno($ch);
	curl_close($ch);
	return $result;
}


 /** WAY BILL FETCH API **/
function wayBillFetch(){
    
	

	// PARAMS
	$token =  getAPIToken();
	$mode  =  getApiMode();


	$cl="DAIKIECOMMERCE%20SURFACE";
	$format = "json";
	$action="fetch";
	$wbn="1685510336906";
	$client_name="DAIKIECOMMERCESURFACE";
    
    // headers
	$headers[] = "Authorization: token $token";
	$headers[] = "Content-Type: application/json";
	$headers[] = "Accept: application/json"; 

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

   $myurl = $mode =='0' ?
			"https://test.delhivery.com/waybill/api/action/json/?cl=$cl&format=$format&action=$action&wbn=$wbn&client_name=$client_name&token=$token":
			"https://track.delhivery.com/waybill/api/$action/json/?cl=$cl&format=$format&action=$action&wbn=$wbn&client_name=$client_name&token=$token";

//$myurl="https://track.delhivery.com/waybill/api/fetch/json/?cl=DAIKIECOMMERCE%20SURFACE&format=json&action=fetch&wbn=1685510336906&client_name=DAIKIECOMMERCESURFACE&token=6cb9c561f0b293836847e78b66d5f8be70566719"
   
	
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	//$result = json_encode($result);
	//echo $result;

	return $result;

 }

/** PACKAGE SLIP API **/
function createPackageSlip(){

	$token =  getAPIToken();
	$mode  =  getApiMode();


	// headers
	$headers[] = "authorization: token $token";
	$headers[] = "accept: application/json";

	// PARAMS
	$wbns  = "1685510336906";

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

	$myurl = $mode =='0' ?
	                "https://test.delhivery.com/api/p/packing_slip/?token=$token&wbns=$wbns":
					"https://track.delhivery.com/api/p/packing_slip/?token=$token&wbns=$wbns";

	// $myurl = "https://track.delhivery.com/api/p/packing_slip/?token=6cb9c561f0b293836847e78b66d5f8be70566719&wbns=1685510336906"; 
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	return $result;
}


/** PACKAGE/ORDER TRACKER  **/
function trackOrder($waybill){


	$token =  getAPIToken();
	$mode  =  getApiMode();
    
    // headers
	$headers[] = "Authorization: token $token";
	$headers[] = "Content-Type: application/json";
	$headers[] = "Accept: application/json"; 

	// PARAMS
	$format  = "json";
	$ref_nos = "45";
	$waybill = $waybill;
	$verbose = "0";
	$output = "json";

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

	$myurl = $mode =='0' ?
			"https://test.delhivery.com/api/packages/json/?token=$token&format=$format&ref_nos=$ref_nos&waybill=$waybill&verbose=$verbose&output=$output":
			"https://track.delhivery.com/api/packages/json/?token=$token&format=$format&ref_nos=$ref_nos&waybill=$waybill&verbose=$verbose&output=$output";

			// $myurl = "https://track.delhivery.com/api/packages/json/?token=6cb9c561f0b293836847e78b66d5f8be70566719&format=json&ref_nos=45&waybill=1685510336906&verbose=0&output=json";
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	return $result;
}


/** SHIPPING CHARGE API  **/
function getShippingCharge($opin,$dpin,$total_weight){
	// HEADERS
	$headers[] = "";

	// PARAMS
	//$format  = "json";
	//$cl​  = "test";
	$pt  = "Prepaid";
	$token =  getAPIToken();
	$mode  =  getApiMode();
	// headers
	$headers[] = "Authorization: token $token";
	$headers[] = "Content-Type: application/json";
	$headers[] = "Accept: application/json";
	//$cod  = "100";
	$gm  = $total_weight;
	$o_pin  = $opin;
	$d_pin  = $dpin;
	//$o_city  = "delhi";
	//$d_city  = "delhi";
	//$md = "E";

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

	$myurl = $mode =='0' ?
		"https://test.delhivery.com/kinko/api/invoice/charges/json/?pt=$pt&token=$token&gm=$gm&o_pin=$o_pin&d_pin=$d_pin":
		"https://track.delhivery.com/kinko/api/invoice/charges/json/?pt=$pt&token=$token&gm=$gm&o_pin=$o_pin&d_pin=$d_pin";
    //$myurl = "https://track.delhivery.com/kinko/api/invoice/charges/json/?pt=prepaid&token=6cb9c561f0b293836847e78b66d5f8be70566719&gm=500&o_pin=384001&d_pin=384001";
	
	//$myurl = "https://test.delhivery.com/kinko/api/invoice/charges/json/?format=$format&cl​=$cl&pt=$cod&token=$token&cod=$cod&gm=$gm&o_pin=$o_pin&d_pin=$d_pin&o_city=$o_city&d_city=$d_city&md=$md";
	
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	return $result;
}


/** EDIT PACKAGE API **/
function editPackage($data){

	$token =  getAPIToken();
	$mode  =  getApiMode();

	// headers
	$headers[] = "Authorization: token $token";
	$headers[] = "Content-Type: application/json";
	$headers[] = "Accept: application/json";

	// PARAMS
	$edit_waybill_data =  $data;

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

	$myurl = $mode =='0' ?
					"https://test.delhivery.com/api/p/edit":
					"https://track.delhivery.com/api/p/edit";
	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$edit_waybill_data);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	return $result;
}

/** CANCEL PACKAGE API **/
function cancelPackage($waybill){

	$token =  getAPIToken();
	$mode  =  getApiMode();

	// headers
	$headers[] = "Authorization: token $token";
	$headers[] = "Content-Type: application/json";
	$headers[] = "Accept: application/json";

	// PARAMS
	$cancel_waybill_data =  json_encode(array(
					'waybill'=>$waybill,
					'cancellation'=>'true'
			));

	$ch = curl_init();
	$timeout = 100; // set to zero for no timeout

	$myurl = $mode =='0' ?
				"https://test.delhivery.com/api/p/edit":
				"https://track.delhivery.com/api/p/edit";


	curl_setopt ($ch, CURLOPT_URL, $myurl);
	curl_setopt ($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_POSTFIELDS,$cancel_waybill_data);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$result = curl_exec($ch);
	$curl_error = curl_errno($ch);
	curl_close($ch);
	return $result;
}
?>