<?php 
	
	/*
		This is the template for the footer
		
		@package sunsettheme
	*/
	
?>

<footer class="sunset-footer text-center">This is the footer</footer>

<?php wp_footer(); ?>
</body>
</html>